; TODO: Add solaris support
